from . PixelStyle1 import *
from . PixelStyle2 import *
from . Array import *

__version__ = '1.0.0'
__author__ = 'Federico Cacciotti'
